#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "payloadselect.h"
#include "payloadimport.h"
#include "exploitrun.h"
#include "updatefusee.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_ExploitMbtn_clicked();

    void on_PayloadSelectMbtn_clicked();

    void on_PayloadImportMbtn_clicked();

    void on_UpdateMbtn_clicked();

private:
    Ui::MainWindow *ui;
    PayloadSelect *PS;
    PayloadImport *PI;
    ExploitRun *EX;
    UpdateFusee *UP;
};

#endif // MAINWINDOW_H
