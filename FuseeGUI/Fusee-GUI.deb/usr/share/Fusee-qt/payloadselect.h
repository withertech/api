#ifndef PAYLOADSELECT_H
#define PAYLOADSELECT_H

#include <QDialog>

namespace Ui {
class PayloadSelect;
}

class PayloadSelect : public QDialog
{
    Q_OBJECT

public:
    explicit PayloadSelect(QWidget *parent = 0);
    ~PayloadSelect();

private slots:
    void on_RefreshPEbtn_clicked();

    void on_OkCancelPSbtn_accepted();

private:
    Ui::PayloadSelect *ui;
};

#endif // PAYLOADSELECT_H
