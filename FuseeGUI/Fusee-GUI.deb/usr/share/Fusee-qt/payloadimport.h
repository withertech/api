#ifndef PAYLOADIMPORT_H
#define PAYLOADIMPORT_H

#include <QDialog>

namespace Ui {
class PayloadImport;
}

class PayloadImport : public QDialog
{
    Q_OBJECT

public:
    explicit PayloadImport(QWidget *parent = 0);
    ~PayloadImport();

private slots:
    void on_PayloadImportPickerPIbtn_clicked();

    void on_OkCancelPIbtn_accepted();

private:
    Ui::PayloadImport *ui;
};

#endif // PAYLOADIMPORT_H
