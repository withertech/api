#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ExploitMbtn_clicked()
{
      EX = new ExploitRun(this);
      EX->show();
}

void MainWindow::on_PayloadSelectMbtn_clicked()
{
      PS = new PayloadSelect(this);
      PS->show();
}

void MainWindow::on_PayloadImportMbtn_clicked()
{
      PI = new PayloadImport(this);
      PI->show();
}

void MainWindow::on_UpdateMbtn_clicked()
{
      UP = new UpdateFusee(this);
      UP->show();
}
