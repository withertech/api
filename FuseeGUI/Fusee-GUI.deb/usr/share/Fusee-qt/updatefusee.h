#ifndef UPDATEFUSEE_H
#define UPDATEFUSEE_H

#include <QDialog>

namespace Ui {
class UpdateFusee;
}

class UpdateFusee : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateFusee(QWidget *parent = 0);
    ~UpdateFusee();

private slots:
    QString commands(QString program);

    void on_UpdateUPbtn_clicked();

private:
    Ui::UpdateFusee *ui;
};

#endif // UPDATEFUSEE_H
