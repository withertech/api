#ifndef GLOBAL_H
#define GLOBAL_H
#include <QString>
#endif // GLOBAL_H
extern QString PayloadEX;
extern QString PayloadPI;
