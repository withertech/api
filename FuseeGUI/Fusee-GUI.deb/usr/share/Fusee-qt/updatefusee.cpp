#include "updatefusee.h"
#include "ui_updatefusee.h"
#include <QProcess>

UpdateFusee::UpdateFusee(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateFusee)
{
    ui->setupUi(this);
}

UpdateFusee::~UpdateFusee()
{
    delete ui;
}

QString UpdateFusee::commands(QString program)
{
    QProcess process;
    process.start(program);
    while (process.waitForFinished()){
        ;
    }
    QString resp = QString::fromLocal8Bit(process.readAllStandardOutput());
    QString error = QString::fromLocal8Bit(process.readAllStandardError());
    return resp + error;
}

void UpdateFusee::on_UpdateUPbtn_clicked()
{
    QString program = "sudo /usr/share/fusee/update";
    ui->UpdateOutputUP->appendPlainText(commands(program));
}
