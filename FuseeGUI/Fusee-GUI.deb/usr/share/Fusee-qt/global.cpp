#include "global.h"
#include "QString"
QString PayloadEX = "";
QString PayloadPI = "";
