#include "payloadselect.h"
#include "ui_payloadselect.h"
#include "global.h"
#include <QDir>
#include <QList>
#include <QString>

PayloadSelect::PayloadSelect(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PayloadSelect)
{
    ui->setupUi(this);
    QDir dir("//usr//share//fusee//Payloads//");
    foreach (QFileInfo var, dir.entryInfoList()) {
        if(var.isFile()) {
            ui->PayloadListPSlist->addItem(var.absoluteFilePath());
        }
    }
}

PayloadSelect::~PayloadSelect()
{
    delete ui;
}

void PayloadSelect::on_RefreshPEbtn_clicked()
{
    ui->PayloadListPSlist->clear();
    QDir dir("//usr//share//fusee//Payloads//");
    foreach (QFileInfo var, dir.entryInfoList()) {
        if(var.isFile()) {
            ui->PayloadListPSlist->addItem(var.absoluteFilePath());
        }
    }
}

void PayloadSelect::on_OkCancelPSbtn_accepted()
{
    PayloadEX = ui->PayloadListPSlist->currentItem()->text();
}
