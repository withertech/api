#include "payloadimport.h"
#include "global.h"
#include "ui_payloadimport.h"
#include <QString>
#include <QFileDialog>
#include <QProcess>
#include <QDebug>

PayloadImport::PayloadImport(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PayloadImport)
{
    ui->setupUi(this);
}

PayloadImport::~PayloadImport()
{
    delete ui;
}

void PayloadImport::on_PayloadImportPickerPIbtn_clicked()
{
    PayloadPI = QFileDialog::getOpenFileName(this, "Choose Payload", "//");
    ui->PayloadImportFileBoxPItxt->setText(PayloadPI);
}

void PayloadImport::on_OkCancelPIbtn_accepted()
{
    QString cp1 = "sudo cp ";
    QString cp2 = "//usr//share//fusee//Payloads//";
    QString PayloadPathPI = PayloadPI.replace('/', "//") + " ";
    QString Payloadcp = cp1 + PayloadPathPI + cp2;
    QProcess::execute(Payloadcp);
}
